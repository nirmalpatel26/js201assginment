function studentData() {
  return {}
}

export {
  studentData
}
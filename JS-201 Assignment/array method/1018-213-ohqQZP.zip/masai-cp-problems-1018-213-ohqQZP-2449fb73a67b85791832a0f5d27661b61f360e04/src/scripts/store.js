function append(data) {}

function remove(index) {
  // logic to remove the mobiles data on selected index
}

function sortLowToHigh() {
  // sort the list of mobiles in ascendning order of price
}

function sortHighToLow() {
  // sort the list of mobiles in descending order of the price
}

// do not change this
if (typeof exports !== "undefined") {
  module.exports = {
    append,
    remove,
    sortLowToHigh,
    sortHighToLow,
  };
}

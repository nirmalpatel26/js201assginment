function getInputData(){
}

function addData(name, brand, price, image) {
  
}

// do not change this
if (typeof exports !== "undefined") {
  module.exports = {
    addData,
  };
}